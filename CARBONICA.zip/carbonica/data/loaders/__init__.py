"""
CARBONICA Data Loaders Package

Individual loaders for each data source
"""

from carbonica.data.loaders.keeling_loader import KeelingLoader
from carbonica.data.loaders.socat_loader import SOCATLoader
from carbonica.data.loaders.gcp_loader import GCPLoader
from carbonica.data.loaders.gtnp_loader import GTNPLoader
from carbonica.data.loaders.glodap_loader import GLODAPLoader
from carbonica.data.loaders.modis_loader import MODISLoader
from carbonica.data.loaders.sif_loader import SIFLoader

__all__ = [
    "KeelingLoader",
    "SOCATLoader",
    "GCPLoader", 
    "GTNPLoader",
    "GLODAPLoader",
    "MODISLoader",
    "SIFLoader"
]
