"""
CARBONICA Integration Tests
"""
