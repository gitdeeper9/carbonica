# 🌍 CARBONICA Netlify Dashboard

**Advanced Planetary Carbon Accounting & Feedback Dynamics**

[![Netlify Status](https://api.netlify.com/api/v1/badges/carbonica/deploy-status)](https://carbonica.netlify.app)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.18995446-orange)](https://doi.org/10.5281/zenodo.18995446)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 🚀 Live Dashboard
- **Dashboard:** [https://carbonica.netlify.app](https://carbonica.netlify.app)
- **API:** [https://carbonica.netlify.app/api](https://carbonica.netlify.app/api)
- **PCSI Monitor:** [https://carbonica.netlify.app/pcsi](https://carbonica.netlify.app/pcsi)
- **Reports:** [https://carbonica.netlify.app/reports](https://carbonica.netlify.app/reports)
- **Documentation:** [https://carbonica.netlify.app/docs](https://carbonica.netlify.app/docs)

## 📊 Current Status (2025)

| Metric | Value |
|--------|-------|
| **PCSI** | 0.78 / 1.00 |
| **Status** | 🟡 TRANSITIONAL |
| Revelle Factor | 12.4 |
| Permafrost Flux | 1.71 PgC/yr |
| Φ_q Decline | -0.9%/decade |

## 📡 API Endpoints

| Endpoint | Description | Parameters |
|----------|-------------|------------|
| `/api/pcsi` | Current PCSI value | `year` (default: 2025) |
| `/api/parameters` | Eight parameters data | `year` (default: 2025) |
| `/api/revelle` | Revelle Factor time series | - |
| `/api/permafrost` | Permafrost flux data | - |
| `/api/projections` | SSP scenario projections | `scenario`, `end_year` |
| `/api/alerts` | Critical threshold alerts | - |
| `/api/history` | Historical PCSI data | `start_year`, `end_year` |

### Example API Call
```bash
# Get current PCSI
curl https://carbonica.netlify.app/api/pcsi?year=2025

# Get SSP3-7.0 projection to 2050
curl https://carbonica.netlify.app/api/projections?scenario=SSP3-7.0&end_year=2050
```

📈 Key Metrics

Metric Value
PCSI vs Keeling Curve (r²) 0.947
Revelle Factor (1960→2025) 10.2 → 12.4
Permafrost Flux (1990→2025) 0.0 → 1.71 PgC/yr
Φ_q Global Decline -0.9%/decade
Time Series Length 65 years
Monte Carlo Ensemble 10,000 members

🔧 Local Development

```bash
# Clone repository
git clone https://github.com/gitdeeper9/carbonica.git
cd carbonica/Netlify

# Install Netlify CLI
npm install -g netlify-cli

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Start local server
netlify dev
```

🏗️ Project Structure

```
Netlify/
├── public/                 # Static files
│   ├── index.html         # Main dashboard
│   ├── dashboard.html      # Live PCSI dashboard
│   ├── pcsi.html          # PCSI monitor
│   ├── revelle-factor.html # Revelle Factor tracker
│   ├── permafrost.html     # Permafrost monitor
│   └── reports.html        # Reports archive
├── functions/              # Netlify Functions
│   ├── pcsi.js            # PCSI endpoint
│   ├── parameters.js       # Eight parameters data
│   ├── revelle.js         # Revelle Factor data
│   ├── permafrost.js       # Permafrost flux data
│   ├── projections.js      # SSP scenario projections
│   ├── alerts.js          # Critical threshold alerts
│   └── history.js         # Historical data
├── package.json           # Dependencies
├── netlify.toml           # Netlify configuration
└── .env.example           # Environment variables template
```

🗄️ Database Schema (Supabase)

```sql
-- Parameters table (eight parameters)
CREATE TABLE carbonica_parameters (
  param_id SERIAL PRIMARY KEY,
  year INTEGER NOT NULL,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  pcsi_value DECIMAL(4,3),
  pcsi_status VARCHAR(20),
  npp_value DECIMAL(5,2),
  s_ocean_value DECIMAL(5,2),
  g_atm_value DECIMAL(4,2),
  f_perma_value DECIMAL(4,2),
  beta_value DECIMAL(5,3),
  tau_soil_value DECIMAL(4,1),
  e_anth_value DECIMAL(4,2),
  phi_q_value DECIMAL(5,4)
);

-- Projections table
CREATE TABLE carbonica_projections (
  proj_id SERIAL PRIMARY KEY,
  scenario VARCHAR(20) NOT NULL,
  year INTEGER NOT NULL,
  pcsi_low DECIMAL(4,3),
  pcsi_mean DECIMAL(4,3),
  pcsi_high DECIMAL(4,3)
);

-- Alerts table
CREATE TABLE carbonica_alerts (
  alert_id SERIAL PRIMARY KEY,
  alert_timestamp TIMESTAMPTZ DEFAULT NOW(),
  alert_type VARCHAR(30),
  alert_level VARCHAR(20),
  pcsi_value DECIMAL(4,3),
  parameter_name VARCHAR(20),
  parameter_value DECIMAL(10,4),
  threshold_value DECIMAL(10,4),
  message TEXT,
  resolved BOOLEAN DEFAULT FALSE
);
```

📖 Citation

If you use CARBONICA in your research, please cite:

```bibtex
@software{baladi2026carbonica,
  author = {Baladi, Samir},
  title = {CARBONICA: Advanced Planetary Carbon Accounting \& Feedback Dynamics},
  year = {2026},
  version = {1.0.0},
  doi = {10.5281/zenodo.18995446},
  url = {https://github.com/gitdeeper9/carbonica}
}
```

📬 Contact

· Author: Samir Baladi
· Email: gitdeeper@gmail.com
· ORCID: 0009-0003-8903-0029
· GitHub: github.com/gitdeeper9/carbonica
· DOI: 10.5281/zenodo.18995446

---

🌍 CARBONICA — Weighing the Breath of the Earth.
