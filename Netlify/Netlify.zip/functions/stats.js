// CARBONICA Netlify Function - Dashboard Stats API
// Returns real dashboard statistics from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Get dashboard stats
    const { data: stats, error } = await supabase
      .from('dashboard_stats')
      .select('*');
    
    if (error) throw error;
    
    // Get additional real-time stats
    const { count: stationsCount } = await supabase
      .from('stations')
      .select('*', { count: 'exact', head: true });
    
    const { count: parametersCount } = await supabase
      .from('parameters')
      .select('*', { count: 'exact', head: true });
    
    const { count: alertsCount } = await supabase
      .from('alerts')
      .select('*', { count: 'exact', head: true })
      .eq('resolved', false);
    
    // Get latest global PCSI
    const { data: latestParams } = await supabase
      .from('parameters')
      .select('pcsi_value, timestamp')
      .eq('station_id', (await supabase.from('stations').select('station_id').eq('station_code', 'MLO').single()).data?.station_id)
      .order('timestamp', { ascending: false })
      .limit(1)
      .single();

    // Convert stats array to object
    const statsObj = stats.reduce((acc, stat) => {
      acc[stat.stat_name] = stat.stat_value;
      return acc;
    }, {});

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        stats: statsObj,
        realtime: {
          total_stations: stationsCount,
          total_measurements: parametersCount,
          active_alerts: alertsCount,
          current_pcsi: latestParams?.pcsi_value || 0.78,
          last_update: latestParams?.timestamp
        }
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
