// CARBONICA Netlify Function - Projections API
// Returns SSP scenario projections from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const scenario = event.queryStringParameters?.scenario;
    const endYear = parseInt(event.queryStringParameters?.end_year) || 2070;
    
    let query = supabase
      .from('projections')
      .select('*')
      .lte('year', endYear)
      .order('scenario')
      .order('year');
    
    if (scenario && scenario !== 'all') {
      query = query.eq('scenario', scenario);
    }
    
    const { data: projections, error } = await query;
    
    if (error) throw error;
    
    // Group by scenario
    const grouped = projections.reduce((acc, proj) => {
      if (!acc[proj.scenario]) {
        acc[proj.scenario] = [];
      }
      acc[proj.scenario].push({
        year: proj.year,
        pcsi_low: proj.pcsi_low,
        pcsi_mean: proj.pcsi_mean,
        pcsi_high: proj.pcsi_high
      });
      return acc;
    }, {});

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        scenarios: grouped
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
