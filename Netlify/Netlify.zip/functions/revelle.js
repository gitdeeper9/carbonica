// CARBONICA Netlify Function - Revelle Factor
// Returns ocean buffer capacity data

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Revelle Factor time series
    const revelleData = [
      { year: 1750, value: 9.1, beta: 0.110 },
      { year: 1960, value: 10.2, beta: 0.098 },
      { year: 1970, value: 10.5, beta: 0.095 },
      { year: 1980, value: 10.9, beta: 0.092 },
      { year: 1990, value: 11.3, beta: 0.088 },
      { year: 2000, value: 11.7, beta: 0.085 },
      { year: 2010, value: 12.0, beta: 0.083 },
      { year: 2020, value: 12.2, beta: 0.082 },
      { year: 2025, value: 12.4, beta: 0.081 }
    ];

    // Future projections
    const projections = [
      { year: 2030, value: 12.8, beta: 0.078 },
      { year: 2040, value: 13.4, beta: 0.075 },
      { year: 2050, value: 14.0, beta: 0.071 }
    ];

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        current: revelleData[revelleData.length - 1],
        historical: revelleData,
        projections: projections,
        buffer_loss: "36% since pre-industrial",
        critical_threshold: 14.0
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
